# Tunnel-Rush

## How to run

Clone the repository and open `index.html` in your browser.

## Controls

* `a` and `d` to turn left and right
* `spacebar` to jump
* `t` to switch texture
* `b` to switch grayscale
